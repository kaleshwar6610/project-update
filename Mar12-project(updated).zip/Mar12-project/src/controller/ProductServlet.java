package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import model.Product;
import model.ProductDaoImpl;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String productId=request.getParameter("productId");
		response.setContentType("text/html");
		String productName=request.getParameter("productName");
		Integer price=Integer.valueOf(request.getParameter("price"));
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		String sdate="";
		sdate=request.getParameter("mfd");
		Date mfdDate=null;
		
			try {
				mfdDate=sdf.parse(sdate);
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		if(mfdDate==null)
			return;
		String vendorId=request.getParameter("vendorId");
		Product product=new Product(productId, productName, price, mfdDate, null, vendorId);
		ProductDaoImpl adao=new ProductDaoImpl();
		int no=0;
		try {
			no=adao.create(product);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		out.println(no+" row(s) affected");
		
		List<Product> productList =null;
		
			try {
				productList=adao.read();
			} catch (ClassNotFoundException | SQLException | java.text.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		if(productList==null)
			return;
		out.println("<table border=1>");
		out.println("<thead><th>productId</th><th>productName</th><th>price</th>");
		out.println("<th>mfdDate</th><th>vendorId</th>");
		for(Product a:productList)
		{
			out.println("<tr>");
			out.println("<td>"+a.getPid());
			out.println("</td>");
			out.println("<td>");
			out.println(a.getPname());
			out.println("</td>");
			out.println("<td>");
			out.println(a.getPrice());
			out.println("</td>");
			out.println("<td>");
			out.println(a.getMfd());
			out.println("</td>");
			out.println("<td>");
			out.println(a.getVid());
			out.println("</td>");
			
			
			
			out.println("</tr>");			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
