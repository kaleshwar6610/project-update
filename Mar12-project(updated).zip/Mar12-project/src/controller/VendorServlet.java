package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Vendor;
import model.VendorDaoImpl;

/**
 * Servlet implementation class VendorServlet
 */
@WebServlet("/VendorServlet")
public class VendorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VendorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String vid = request.getParameter("vid");
		String vname = request.getParameter("vname");
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		String sdate="";
		sdate=request.getParameter("aDate");
		Date arrivalDate=null;
		
			try {
				arrivalDate=sdf.parse(sdate);
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		if(arrivalDate==null)
			return;
		Vendor vendor=new Vendor(vid, vname, arrivalDate);
		VendorDaoImpl vdao=new VendorDaoImpl();
		int no=0;
		try {
			no=vdao.create(vendor);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		PrintWriter out= response.getWriter();
		out.println(no+" row(s) affectd");
		
		List<Vendor> vendorList =null;
		
			try {
				vendorList=vdao.read();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		if(vendorList==null)
			return;
		out.println("<table border=1>");
		out.println("<thead><th>vendorId</th><th>vendorName</th>");
		out.println("<th>arrivaldate</th>");
		for(Vendor v:vendorList)
		{
			out.println("<tr>");
				out.println("<td>"+v.getVid());
					out.println("</td>");
				out.println("<td>");
					out.println(v.getVname());
					out.println("</td>");
				out.println("<td>");
					out.println(v.getArrivalDate());
					out.println("</td>");
				
			out.println("</tr>");
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
